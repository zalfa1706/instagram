<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">    <title>Document</title>

    <title>INSTAGRAM</title>
</head>
<body>
<nav class="navbar" style="background-color: #fd7e14">
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">INSTAGRAM Mountain Tour</a>
  </li>
  
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" aria-disabled="true">Zalfa Panca Afifah</a>
  </li>
</ul>
      <a href="logout.php?no=<?= $post['no'] ?>" class="btn btn-outline-secondary">Logout</a>
  </div>
</nav> 
<div class="container" style="margin-top: 80px">
      <div class="row">
        <div class="col-md-5 offset-md-3">
          <div class="card">
          <div class="p-3 mb-2 bg-danger-subtle text-emphasis-danger">
            <div class="card-header">
            Edit
            </div>
            <div class="card-body">
    <form action="proses_edit.php" method="post" 
    enctype="multipart/form-data">
    
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
        
        <div class="form-group">
        <label for="">Gambar</label>
        <input type="file" name="gambar" id="" class="form-control" value="<?= $post['gambar'] ?>" ><br>
        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br>
        </div><br>

        <div class="form-group">
        <label for="">Caption</label>
        <input type="text" name="caption" id="" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>
        </div><br>

        <div class="form-group">
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        </div><br>

        <input type="submit" value="Update" class="btn btn-outline-info" name="update">
    </form>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>

<?php } ?>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>