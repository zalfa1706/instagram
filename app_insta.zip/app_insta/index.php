<?php 
session_start();
include "koneksi.php";
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi,$sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link rel=”stylesheet” href=”https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css”>
    <title>INSTAGRAM</title>
    <style>
     
        .card-img-top {
            transition: transform 0.3s; 
        }
        .card-img-top:hover {
            transform: scale(1.3);
        }
    </style>
  </head>
  <body>
  <body class="" style="background-color:#AED2FF;">

<nav class="navbar fixed-top" style="background-color: #3085C3">
<ul class="nav nav-tabs">
  <li class="nav-item" >
  <div class="container-fluid">
      	
<div class="lingkaran1">
  <a class = "navbar-brand" href = "02.png">
  <img src = "images/02.png" weight="100" height = "50" style="border-radius: 50%;">
    </a>
  </li>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled fw-bold" aria-disabled="true">Mountain Tour</a>
  </li>
  
</ul>
        <span>
      <button type="button" class="btn btn-primary bi bi-plus-square" data-bs-toggle="modal" data-bs-target="#exampleModal"></button>
      <a href="logout.php"><button class="btn btn-secondary"><i class="bi bi-arrow-right-square"></i></button></a>
              </span>      
    </div>
  </div>
</nav>



<center>
<div class= "container mt-5"><br>
    <h1 style="text-align: center:">Daftar Postingan</h1>  
    <?php while ($post = mysqli_fetch_assoc($query)) { ?>
      
    
    <div class="card mx-auto col-md-3 sm-6 mt-4" style="width: 30rem;">
    <img src="images/<?= $post['gambar'] ?>" alt="" class="card-img-top" alt="snow">
  <div class="card-body">
    <h5 class="card-title"><?= $post['caption'] ?></h5>
    <p class="card-text"><?= $post['lokasi'] ?></p>
    <a class="btn btn-warning"data-bs-toggle="modal" data-bs-target="#editModal<?=$post['no']?>"><i class="fa fa-pen-to-square"></i></a>
    <a href="hapus.php?no=<?= $post['no'] ?>"><button class="btn btn-danger"><li class="fa fa-trash-can" style="font-size:20px"></li></button></a>
  </div>
  </div><br>

</div>
</div>
</center>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Form Tambah</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="">Gambar</label>
        <input type="file" name="gambar" class="form-control" required><br>

        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control"autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input type="text" name="lokasi" class="form-control"autocomplete="off"><br>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <input class="btn btn-info" type="submit" value="Add" name="simpan">
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="editModal<?=$post['no']?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModalLabel">Form Edit</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        
      <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">

        <label for="">Gambar</label><br>
        <input type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" ><br><br>
        <img src="images/<?= $post['gambar'] ?>" width="325" height="250" alt="" ><br><br>
        
        <label for="">Caption</label>
        <input  class="form-control" type="text" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" name="update" class="btn btn-warning">Save</button>
        </div>
    </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>