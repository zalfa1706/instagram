<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html>
	<head>
		<title>LOGIN</title>
		<link rel="stylesheet" href="login.css">
	</head>
<body>
	<div class="login-page">
		<div class="image-conteiner">
			<div class="image">
		<img src="images/02.png" alt="" href ="02.png">
			</div>
		</div>
		<div class="title">
			<h5>Login</h5>
		</div>
		<div class="input-value">
			<div class="input">
				<form action="proses_login.php" method="post">
				<label>Username</label><br>
				<input type="text" name="username" id="" placeholder=""/><br><br>
				<label>Password</label><br>
				<input type="password" name="password" id="" placeholder=""/><br><br>
				<input type="submit" value="Login" id="submit"/>
			</div>
			
			
		</div>
	</div>
	</form>
</body>
</html>