<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link rel=”stylesheet” href=”https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css”>
    <title>INSTAGRAM</title>
</head>
<body>
<nav class="navbar" style="background-color: #dc3545;">
<ul class="nav nav-tabs">
  <li class="nav-item" >
  <div class="container-fluid">
      	
<div class="lingkaran1">
  <a class = "navbar-brand" href = "logo.jpg">
  <img src = "logo.jpg" weight="30" height = "30" style="border-radius: 50%;">
    </a>
  </li>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" aria-disabled="true">INSTAGRAM Mountain Tour</a>
  </li>
  
</ul>
        
    <form>
      <!-- <a href="tambah.php" class="btn btn-info"><i class="fa-solid fa-square-plus"></i></a> -->
      <a href="logout.php?no=<?= $post['no'] ?>" class="btn btn-secondary"><i class="fa-solid fa-right-from-bracket"></i></a>
    </form>
  </div>
  </div>
</nav> <br>

<div class= "container">


<div class="container" style="margin-top: 80px">
      <div class="row">
        <div class="col-md-5 offset-md-3">
      
          <div class="card">
          <div class="p-3 mb-2 bg-danger-subtle text-emphasis-danger">
            <div class="card-header">
            Tambah
            </div>
            <div class="card-body">
    <form action="proses_tambah.php" method="post" 
    enctype="multipart/form-data">
     
    <div class="form-group">
                  <label>Gambar</label>
                  <input type="file" name="gambar" class="form-control"required >
                </div><br>

                <div class="form-group">
                  <label>Caption</label>
                  <input type="text" name="caption" class="form-control">
                </div><br>

                <div class="form-group">
                <label>Lokasi</label>
                  <input type="text" name="lokasi" class="form-control">
                </div><br><br>
                
        <input type="submit" value="Simpan" class="btn btn-outline-info" name="simpan">
        
    </form>
      </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>